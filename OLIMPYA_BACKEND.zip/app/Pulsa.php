<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pulsa extends Model
{
    protected $guarded=[];
}
