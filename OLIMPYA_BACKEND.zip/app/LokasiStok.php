<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LokasiStok extends Model
{
    
    protected $guarded=[];
}
