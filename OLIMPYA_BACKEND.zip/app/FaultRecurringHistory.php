<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FaultRecurringHistory extends Model
{
    protected $guarded=[];
}
