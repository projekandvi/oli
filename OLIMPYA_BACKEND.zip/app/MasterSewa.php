<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MasterSewa extends Model
{
    protected $guarded=[];
}
