<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NomorOtomatis extends Model
{
    protected $table = 'auto_numbers';
    protected $guarded=[];
}
