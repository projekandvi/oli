<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Reference extends Model
{
	protected $table = 'tb_reference_number';
    protected $guarded=[];
}
