
    <script>  window.Laravel = {!! json_encode(['csrfToken' => csrf_token() ]); !!}  </script>        
    <!-- Javascripts -->
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/accounting.js/0.4.1/accounting.min.js"></script>
    {{-- <script src="{{ asset('js/transaksi.js') }}"></script> --}}
    <script src="{{ asset('/assets/js-core/slimscroll.js') }}"></script>
    <script src="{{ asset('/assets/js-core/screenfull.js') }}"></script>
    <script defer src="{{ asset('/build/app.b81f4459eb1b0cdac4d5.js') }}"></script>
    <script src="{{ asset('/assets/js-core/sweetalert2.min.js') }}"></script>
    <script src="{{ asset('/assets/js-core/highcharts.js') }}"></script>
    <script src="{{ asset('/assets/js-core/exporting.js') }}"></script>

   

    <script
        src="https://code.jquery.com/jquery-3.2.1.min.js"
        integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
        crossorigin="anonymous"></script> 

        

   
   


   



