<!-- Main Footer -->
<div class="footer bg-black">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
       <!-- Powered By -->
        <a href="http://www.intelle-hub.com">
       		<b>PT. Cosan</b>
       	</a>.
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 
    	<a href="#">
    		Cosan CRM <script>document.write(new Date().getFullYear())</script>
    	</a>
    </strong>
</div>