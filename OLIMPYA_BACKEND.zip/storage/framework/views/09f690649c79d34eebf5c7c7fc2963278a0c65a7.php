<?php $__env->startSection('contentheader'); ?>
    <?php if($barang->id): ?>
        <?php echo e(trans('core.editing')); ?> <b><?php echo e($barang->name); ?></b>
    <?php else: ?>
        add new barang
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <a href="<?php echo e(route('barang.index')); ?>">barang list</a>
     &nbsp;>&nbsp;
    Update Stok <?php echo e($barang->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>

<div class="panel-body">

    <h3 class="title-hero">        
            add new barang        
    </h3>

    
    <?php echo Form::open(['route'=> ['barang.stok', $barang], 'method'=>'post', 'files' => true, 'class' => 'form-horizontal bordered-row', 'id' => 'ism_form']); ?>

        
        <div class="form-group">
            <label class="control-label col-sm-3">Nama Barang<span class="required">*</span></label>
            <div class="col-sm-6">
                <input type="text" class="form-control" placeholder="Nama Barang" name="nama_barang" value="<?php echo e($barang->nama_barang); ?>" />
            </div>
        </div>

        <div class="form-group">
            <label class="control-label col-sm-3">Stok Terakhir<span class="required">*</span></label>
            <div class="col-sm-6">
                <input type="text" class="form-control" value="<?php echo e($barang->stok); ?>"  disabled/>
            </div>
        </div> 

        <div class="form-group">
            <label class="control-label col-sm-3">Stok Tambahan<span class="required">*</span></label>
            <div class="col-sm-6">
                <input type="text" class="form-control" placeholder="Stok Tambahan" name="stok" />
            </div>
        </div>  

        <div class="bg-default content-box text-center pad20A mrg25T">
            <input class="btn btn-lg btn-primary" type="submit" id="submitButton" value="save" onclick="submitted()">
        </div>

    <?php echo e(Form::close()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>