<!-- Content Header (Page header) -->
<div id="page-title">
    <h2>
        <?php $__env->startSection('contentheader'); ?> 
            Museum
            <small style=" font-size: 12px; letter-spacing: 2px;">
                <b><?php echo e(Auth::user()->name); ?></b>
            </small>
        <?php echo $__env->yieldSection(); ?>
    </h2>
    <p><?php $__env->startSection('contentheader_description'); ?> Museum <?php echo $__env->yieldSection(); ?></p>
    <ol class="breadcrumb">
        <li>
            <a href="<?php echo e(route('home')); ?>">
                <i class="fa fa-dashboard"></i> 
                Dashboard
            </a>
        </li>
        <li class="active">
        	<?php $__env->startSection('breadcrumb'); ?>
        		
        	<?php echo $__env->yieldSection(); ?>
        </li>
    </ol>
</div>