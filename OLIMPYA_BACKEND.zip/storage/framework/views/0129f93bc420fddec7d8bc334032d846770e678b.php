<?php $__env->startSection('title'); ?>
	Laporan Teknisi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader'); ?>
Daftar Laporan Teknisi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
Daftar Laporan Teknisi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>

<style>
	.pilihanPencarian {
		display: none;
	}
</style>



<div class="panel-body">

	<h3 class="title-hero">Data Laporan Teknisi</h3>

	<div class="row">
		<div class="col-md-12">
			<?php echo Form::open(['class' => 'form-horizontal','id' => 'ism_form']); ?>

			
				<?php echo csrf_field(); ?>
			                 
				<div class="form-group">
					<label class="col-sm-3" style="text-align: left;">
						Pilihan Pencarian 
					</label>
					<div class="col-sm-9">
						<select id="pencarianSelector" class="form-control" onchange="munculPencarian()">
							<option value="" disabled selected>-- Pilihan Pencarian --</option>
							<option value="so">Slip Order</option>
							<option value="customer">Customer </option>
						</select>
					</div>					
				</div>
				<div class="pilihanPencarian" id="so">
					<div class="form-group  output">
						<label class="col-sm-3" style="text-align: left;">
							No. Slip Order 
						</label>
						<div class="col-sm-9">
							<?php echo Form::select('slip_order_no', $slipOrder, Request::get('slip_order_no'), ['class' => 'form-control selectpicker', 'data-live-search' => 'true', 'placeholder' => 'Please select a slip order']); ?>

						</div>
					</div>
				</div>					
				<div class="pilihanPencarian" id="customer">
					<div class="form-group  output">
						<label class="col-sm-3" style="text-align: left;">
							Customer
						</label>
						<div class="col-sm-9">
							<?php echo Form::select('customer', $customers, Request::get('customer'), ['class' => 'form-control selectpicker', 'data-live-search' => 'true', 'placeholder' => 'Please select a customer']); ?>

						</div>
					</div>
				</div>	
			<div class="bg-default content-box text-center pad20A mrg25T">
				
				<?php echo Form::submit('Search', ['class' => 'btn btn-lg btn-primary', 'data-disable-with' => trans('searching'),'id' => 'submitButton','onclick' => 'submitted()']); ?>

			</div>
		<?php echo Form::close(); ?>

		</div>
	</div>


	<table class="table table-bordered">
		<thead class="bg-gradient-1">
			<td class="text-center font-white">#</td>
			<td class="text-center font-white">ID Slip Order</td>
			<td class="text-center font-white">Nama Customer</td>
			<td class="text-center font-white">alamat</td>
			<td class="text-center font-white">No hp</td>
			<td class="text-center font-white">Action</td>
		</thead>						
		<tbody>
			<?php $__currentLoopData = $so; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td class="text-center"><?php echo e($loop->iteration); ?></td>
					<td class="text-center"><?php echo e($item->id_slip_order); ?></td>
					<td class="text-center"><?php echo e($item->nama_customer); ?></td>
					<td class="text-center"><?php echo e($item->alamat_pemasangan); ?></td>
					<td class="text-center"><?php echo e($item->no_hp); ?></td>
					<td class="text-center">
						<a href="<?php echo e(route('getLaporanTeknisi', $item->id_slip_order)); ?>" class="btn btn-primary btn-xs"> Membuat Laporan </a>
													
					</td>
				</tr>
									
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>					
	<!--Pagination-->
	<div class="pull-right">
		<?php echo e($so->links()); ?>

	</div>
</div>

<div class="panel-footer">  
	<span style="padding: 10px;">	</span> 
	<a class="btn btn-border btn-alt border-primary font-black btn-xs pull-right" href="/slipOrder">
		<i class="fa fa-backward"></i> Kembali
	</a>
</div>

	

<!-- Slip Order search modal -->
<div class="modal fade" id="searchModal">
	<div class="modal-dialog">
		<div class="modal-content">
			
			
		</div>
	</div>
</div>
<!-- search modal ends -->

<!-- bank format recurring modal -->
<div class="modal fade" id="convertModal">
	<div class="modal-dialog">
		<div class="modal-content">
			
			<form action="/bank_format" enctype="multipart/form-data" class="form-horizontal" method="POST">
				<?php echo csrf_field(); ?>
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title"> Konvert data ke format Recurring Bank</h4>
				</div>

				<div class="modal-body">                  
					<div class="form-group">
						<label class="col-sm-3" style="text-align: left;" >
							Dari
						</label>
						<div class="col-sm-9">
							
							<input type="text" name="dari" class="form-control dateTime" placeholder="yyyy-mm-dd">
						</div>
					</div>	
					<div class="form-group">
						<label class="col-sm-3" style="text-align: left;" >
							Ke
						</label>
						<div class="col-sm-9">
							
							<input type="text" name="ke" class="form-control dateTime" placeholder="yyyy-mm-dd">
						</div>
					</div>																 
				</div>

			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">close</button>
				<?php echo Form::submit('Search', ['class' => 'btn btn-primary', 'data-disable-with' => trans('searching')]); ?>

			</div>
			
			</form>
		</div>
	</div>
</div>
<!-- bank format recurring modal ends -->

<!-- perminggu modal -->
<div class="modal fade" id="permingguModal">
	<div class="modal-dialog">
		<div class="modal-content">
			<?php echo Form::open(['class' => 'form-horizontal'],['route'=> ['sewa.perminggu'], 'method'=>'post']); ?>

			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title"> Penjualan Sewa Perminggu</h4>
			</div>

			<div class="modal-body">                  
				
				<div class="form-group">
					<label class="col-sm-3" style="text-align: left;" >
						Dari
					</label>
					<div class="col-sm-9">
						<?php echo Form::text('from', Request::get('from'), ['class' => 'form-control dateTime','placeholder'=>"yyyy-mm-dd"]); ?>

					</div>
				</div>

				<div class="form-group">
					<label class="col-sm-3" style="text-align: left;" >
						Ke
					</label>
					<div class="col-sm-9">
						<?php echo Form::text('to', Request::get('to'), ['class' => 'form-control dateTime','placeholder'=>"yyyy-mm-dd"]); ?>

					</div>
				</div>
																
			</div>

			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">close</button>
				<?php echo Form::submit('Search', ['class' => 'btn btn-primary', 'data-disable-with' => trans('searching')]); ?>

			</div>
			<?php echo Form::close(); ?>

		</div>
	</div>
</div>
<!-- perminggu modal ends -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
<script>
	$(function() {
		$('#searchButton').click(function(event) {
			event.preventDefault();
			$('#searchModal').modal('show')
		});
	});

	$(function() {
		$('#convertButton').click(function(event) {
			event.preventDefault();
			$('#convertModal').modal('show')
		});
	});

	$('#permingguButton').click(function(event) {
			event.preventDefault();
			$('#permingguModal').modal('show')
		});

	$(function() {
		$('#pencarianSelector').change(function(){
			$('.pilihanPencarian').hide();
			$('#' + $(this).val()).show();
		});
    });

	$(document).ready(function(){
        // Format mata uang.
        $( '.uang' ).mask('0.000.000.000', {reverse: true});
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>