<?php $__env->startSection('title'); ?>
	Detail Akunting Bank <?php echo e($nama_bank->nama_bank); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader'); ?>
Detail Akunting Bank <?php echo e($nama_bank->nama_bank); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
Detail Akunting Bank <?php echo e($nama_bank->nama_bank); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>

	<div class="panel-heading">
		
	<a href="/exportExcelPerBank/<?php echo e($nama_bank->kode_bank); ?>" class="btn btn-success btn-alt btn-xs" style="border-radius: 0px !important;">Export to Excel</a>

		<?php if(count(Request::input())): ?>
			<span class="pull-right">	
	            <a class="btn btn-default btn-alt btn-xs" href="<?php echo e(action('InvoiceController@getIndex')); ?>"><i class="fa fa-eraser"></i> clear</a>
	            <a class="btn btn-primary btn-alt btn-xs" id="searchButton"><i class="fa fa-search"></i> modify search </a>
	        </span>
        <?php else: ?>
            <a class="btn btn-primary btn-alt btn-xs pull-right" id="searchButton">	<i class="fa fa-search"></i>search</a>
        <?php endif; ?>
	</div>

	<div class="panel-body">
		<div class="row "> 				

			<table class="table table-bordered">
				<thead class="bg-gradient-1">
					<td class="text-center font-white">#</td>
					<td class="text-center font-white">Tanggal Pembayaran</td>
					<td class="text-center font-white">ID Slip Order</td>
					<td class="text-center font-white">Keterangan Pembayaran</td>
					<td class="text-center font-white">Debet</td>
					<td class="text-center font-white">Kredit</td>
				</thead>						
				<tbody>
					<?php $__currentLoopData = $bank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td class="text-center"><?php echo e($loop->iteration); ?></td>
							<td class="text-center"><?php echo e($item->tanggal_pembayaran); ?></td>
							<td class="text-center">
								<?php if($item->keterangan_pembayaran === 'Pembayaran Recurring'): ?>
									<a href="<?php echo e(route('SO.details', $item->id_slip_order)); ?>"><i class="fa fa-eye" style="color: #269fed;"></i> <?php echo e($item->id_slip_order); ?> </a>
								<?php elseif($item->keterangan_pembayaran === 'Pembayaran Periode'): ?>
									<a href="<?php echo e(route('SO.details', $item->id_slip_order)); ?>"><i class="fa fa-eye" style="color: #269fed;"></i> <?php echo e($item->id_slip_order); ?> </a>
								<?php else: ?> 
									<a href="<?php echo e(route('SO.detailsPutus', $item->id_slip_order)); ?>"><i class="fa fa-eye" style="color: #269fed;"></i> <?php echo e($item->id_slip_order); ?> </a>
								<?php endif; ?>						
							</td>
							<td class="text-center"><?php echo e($item->keterangan_pembayaran); ?></td>
							<td class="text-center">-</td>
							<td class="uang text-right">Rp. <?php echo e(number_format($item->nominal_pembayaran,0,'.','.')); ?></td>							
						</tr>											
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>

			<table style="width: 50%; font-weight: bold;" align="right" class="table table-bordered" >
				<tr style="background-color: #F8F9F9; border: 1px solid #ddd;">
					<td style="text-align: right;"><b>Grand Total :</b></td>
					<td style="text-align: right;">Rp <?php echo e(number_format($bank->sum('nominal_pembayaran'),0,'.','.')); ?></td>
				</tr>				
			</table> 			
		</div>
	</div>

	<div class="panel-footer">  
		<span style="padding: 10px;"></span> 
	  	<a class="btn btn-border btn-alt border-primary font-black btn-xs pull-right" href="/">
			<i class="fa fa-backward"></i> Kembali
		</a>
	</div>	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
	<script>
		$(function() {
            $('#searchButton').click(function(event) {
                event.preventDefault();
                $('#searchModal').modal('show')
            });
        })
	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>