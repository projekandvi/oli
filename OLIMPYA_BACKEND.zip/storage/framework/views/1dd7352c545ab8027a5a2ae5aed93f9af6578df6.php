
<div id="page-sidebar" class="bg-gradient-1 font-inverse">
  <div class="scroll-sidebar">
        
    <ul id="sidebar-menu">
          
        <li class="no-menu" >
            <a href="#">
                <i class='fa fa-th'></i> 
                <span>Home</span>
            </a>
        </li>

        <li class="no-menu" >
            <a href="<?php echo e(route('category.index')); ?>">
                <i class='fa fa-tag'></i>
                <span>Category</span>
            </a>
        </li>

        <li class="no-menu">
            <a href="<?php echo e(route('subcategory.index')); ?>"> 
                <i class='fa fa-tags'></i>
                <span>Subcategory</span>
            </a>
        </li>

        <li class="no-menu">
            <a href="<?php echo e(route('destination.index')); ?>"> 
                <i class='fa fa-map-marker'></i>
                <span>Destination</span>
            </a>
        </li>

        <li class="no-menu">
            <a href="<?php echo e(route('gallery.index')); ?>"> 
                <i class='fa fa-photo'></i>
                <span>Gallery</span>
            </a>
        </li>

      
       
    </ul><!-- #sidebar-menu -->
  </div>
</div>

