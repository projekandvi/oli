<div id="page-header" class="bg-gradient-1  "  >
    
    <div id="mobile-navigation">
        <button id="nav-toggle" class="collapsed" data-toggle="collapse" data-target="#page-sidebar"><span></span></button>
        <a href="<?php echo e(url('/')); ?>" class="logo-content-small" title="Museum Management System"></a>
    </div>

    <div id="header-logo" class="logo-bg">
        <img class="logo-content-big" style="width: 200px;" src="<?php echo e(asset('img/dashboard_logo.png')); ?>" alt="">
        
           <a href="#" class="logo-content-big" title="CRM">
               CRM
               <span>Keren</span>
           </a>
           <a href="#" class="logo-content-small" title="CRM">
               CRM
               <span>keren</span>
           </a>
           <a id="close-sidebar" href="#" title="Close sidebar">
               <i class="glyph-icon icon-angle-left"></i>
           </a>
       </div>

    <div id="header-nav-left">
        <div class="user-account-btn dropdown">
            <a href="#" title="My Account" class="user-profile clearfix" data-toggle="dropdown">
                
                  <img src="<?php echo e(asset('img/default.png')); ?>" class="user-image" alt="" />
                
                <span style="display: block; height: 20px;"><?php echo e(Auth::user()->email); ?></span>
                <i class="glyph-icon icon-angle-down"></i>
            </a>
            <div class="dropdown-menu float-left">
                <div class="box-sm">
                    <div class="login-box clearfix">
                        <div class="user-img">
                            <a href="#" title="" class="change-img">Change photo</a>
                            <?php if(Auth::user() || Auth::user()->image ): ?>
                              <img src="<?php echo e(asset('img/default.png')); ?>" class="user-image" alt="" />
                            <?php else: ?>
                              <img src="<?php echo asset('uploads/profiles/'. Auth::user()->image); ?>" class="user-image" alt="<?php echo e(Auth::user()->first_name); ?>"/>
                            <?php endif; ?>
                        </div>
                        <div class="user-info">
                            <span>
                              <?php if(Auth::user()): ?>
                                  <?php echo e(Auth::user()->name); ?>

                                  <i>Member since  <?php echo e(Auth::user()->created_at); ?></i>
                              <?php else: ?>
                                  Not logged in
                              <?php endif; ?>
                            </span>
                        </div>
                    </div>
                    
                    <div class="pad5A button-pane button-pane-alt text-center">
                        

                        <a class="btn display-block font-normal btn-danger" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();"><i class="glyph-icon icon-power-off"></i>
                                    Logout
                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- #header-nav-left -->

    <div id="header-nav-right">
        <!--fulscreen-->
        <a href="#" class="hdr-btn tooltip-button" id="fullscreen-btn" data-placement="bottom" title="Fullscreen">
            <i class="glyph-icon icon-arrows-alt"></i>
        </a>
        <!--ends-->

        
        
        

        <!--Notification-->
        <div class="dropdown" id="notifications-btn">
            <a data-toggle="dropdown" href="#" data-placement="bottom" title="Alert Maintenance Tempo" class="tooltip-button" 
                <?php if($reminderTempoMaintenance->count() > 0): ?> 
                    style="background-color: #FFE941CC !important;" 
                <?php endif; ?>
            >
                <i class="glyph-icon icon-linecons-megaphone" 
                    <?php if($reminderTempoMaintenance->count() > 0): ?> 
                        style="color: red;text-shadow: 1px 1px 1px #ccc;"
                    <?php endif; ?>>
                </i>
            </a>

            <div class="dropdown-menu float-right box-md">
                <?php if($reminderTempoMaintenance->count() > 0): ?>
                    <div class="popover-title display-block clearfix pad10A">
                        Alert Maintenance Tempo : <?php echo e($reminderTempoMaintenance->count()); ?> Slip Order 
                    </div>
                    
                    <div class="scrollable-content scrollable-slim-box">
                        <ul class="no-border notifications-box">
                            <?php $__currentLoopData = $reminderTempoMaintenance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <ul>
                                    <li><span class="bg-danger icon-notification glyph-icon icon-bullhorn"></span> 
                                        No. Slip Order : <?php echo e($item->id_slip_order); ?>

                                    </li>
                            </ul>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div class="pad10A button-pane button-pane-alt text-center">
                        <a href="/daftarMaintenanceTempo" class="btn btn-primary" title="View all notifications">
                            Proses
                        </a>
                    </div>
                <?php endif; ?>
                
                
                <div class="popover-title display-block clearfix pad10A">
                    Alert Maintenance Tempo : <?php echo e($reminderTempoMaintenance->count()); ?> Slip Order 
                </div>
                   
                <div class="scrollable-content scrollable-slim-box">
                    <ul class="no-border notifications-box">
                        <?php $__currentLoopData = $reminderTempoMaintenance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <ul>
                                <li><span class="bg-danger icon-notification glyph-icon icon-bullhorn"></span> 
                                    No. Slip Order : <?php echo e($item->id_slip_order); ?>

                                </li>
                           </ul>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="pad10A button-pane button-pane-alt text-center">
                    <a href="/daftarMaintenanceTempo" class="btn btn-primary" title="View all notifications">
                        Proses
                    </a>
                </div>
            </div>
        </div>
        <!--Notification Ends-->

        <!--Calculator-->
        <div class="dropdown" id="notifications-btn" >
          <a  href="#" data-toggle="dropdown" data-placement="bottom" title="Calculator" class="tooltip-button">
              <i class="glyph-icon fa fa-calculator"></i>
          </a>
          <div class="dropdown-menu float-right box-md">
                <div class="scrollable-content scrollable-slim-box">
                   <?php echo $__env->make('partials.calculator', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>

        </div>
        <!--Calculator-->

        

        
    </div><!-- #header-nav-right -->
</div><!-- header ends -->








