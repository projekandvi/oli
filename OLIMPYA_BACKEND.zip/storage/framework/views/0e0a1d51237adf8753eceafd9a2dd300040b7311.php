

<?php $__env->startSection('title'); ?>
	Gallery
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader'); ?>
	Gallery List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
	Gallery List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>

	<div class="panel-heading">
		
			<a href="<?php echo e(route('gallery.new')); ?>" class="btn btn-success btn-alt btn-xs" style="border-radius: 0px !important;">
				<i class='fa fa-plus'></i> 
				Add new Gallery
			</a>

		<?php if(count(Request::input())): ?>
			<span class="pull-right">	
	            <a class="btn btn-default btn-alt btn-xs" href="<?php echo e(action('GalleryController@getIndex')); ?>">
	            	<i class="fa fa-eraser"></i> 
	            	clear
	            </a>

	            <a class="btn btn-primary btn-alt btn-xs" id="searchButton">
	            	<i class="fa fa-search"></i> 
	            	modify search
	            </a>
	        </span>
        <?php else: ?>
            <a class="btn btn-primary btn-alt btn-xs pull-right" id="searchButton">
				<i class="fa fa-search"></i>
				search
			</a>
        <?php endif; ?>
	</div>

	<div class="panel-body">

		<table class="table table-bordered">
			<thead class="bg-gradient-1">
				<td class="text-center font-white">#</td>
				<td class="text-center font-white">destination</td>
				<td class="text-center font-white">display</td>
				<td class="text-center font-white">file type</td>
				<td class="text-center font-white">action</td>
			</thead>

			<tbody>
				<?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td class="text-center"><?php echo e($loop->iteration); ?></td>
						<td class="text-center"><?php echo e($gallery->destination->name); ?></td>
						<td class="text-center" style="width: 25%"><img src="<?php echo asset('uploads/galleries/'.$gallery->name); ?>" class="img-responsive img-thumbnail" style="max-width: 75%" alt="Gallery Image" width="200px" /></td>
						<td class="text-center"><?php echo e($gallery->filetype); ?></td>
						
						<td class="text-center">

								<a href="<?php echo e(route('gallery.edit', $gallery)); ?>" class="btn btn-info btn-alt btn-xs">
									<i class="fa fa-edit"></i>
									edit
								</a>							
						</td>
					</tr>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>

		<!--Pagination-->
		<div class="pull-right">
			<?php echo e($galleries->links()); ?>

		</div>
		<!--Ends-->
	</div>

	<!-- Gallery search modal -->
    <div class="modal fade" id="searchModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <?php echo Form::open(['class' => 'form-horizontal']); ?>

                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"> <?php echo e(trans('core.search').' '.trans('core.customer')); ?></h4>
                </div>

                <div class="modal-body">                  
                    <div class="form-group">
                        <?php echo Form::label('filetype', trans('filetype'), ['class' => 'col-sm-3']); ?>

                        <div class="col-sm-9">
                            <?php echo Form::text('filetype', Request::get('filetype'), ['class' => 'form-control']); ?>

                        </div>
                    </div>                                             
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">close</button>
                    <?php echo Form::submit('Search', ['class' => 'btn btn-primary', 'data-disable-with' => trans('searching')]); ?>

                </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
	<!-- search modal ends -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
	<script>
		$(function() {
            $('#searchButton').click(function(event) {
                event.preventDefault();
                $('#searchModal').modal('show')
            });
        })
	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>