<?php $__env->startSection('contentheader'); ?>
    <?php if($gallery->id): ?>
        <?php echo e(trans('core.editing')); ?> <b><?php echo e($gallery->name); ?></b>
    <?php else: ?>
        add new gallery
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <a href="<?php echo e(route('gallery.index')); ?>">gallery list</a>
     &nbsp;>&nbsp;
    edit <?php echo e($gallery->name); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main-content'); ?>

<div class="panel-body">

    <h3 class="title-hero">
        
            add new gallery
        
    </h3>

    <?php echo Form::model($gallery, ['method' => 'post', 'files' => true, 'class' => 'form-horizontal bordered-row', 'id' => 'ism_form']); ?>


        <div class="form-group">
            <label class="control-label col-sm-3">Destination ID<span class="required">*</span></label>
            <div class="col-sm-6">
                <input type="text" class="form-control" placeholder="destination id" name="destination_id" value="<?php echo e($gallery->destination_id); ?>" />
            </div>
        </div>

        <div class="form-group">
                <label class="control-label col-sm-3">File Type<span class="required">*</span></label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" placeholder="File Type" name="filetype" value="<?php echo e($gallery->filetype); ?>" />
                </div>
            </div>

        <div class="form-group">
            <div class="col-sm-3 col-sm-offset-3" >
                <?php if($gallery->image): ?>
                    <img src="<?php echo asset('uploads/galleries/'.$gallery->image); ?>" class="img-responsive img-thumbnail" alt="Gallery Image" height="45" width="45" />
                <?php else: ?>
                    <img src="<?php echo e(asset('uploads/galleries/default_pp.png')); ?>" class="img-responsive img-thumbnail" alt="Gallery Image" height="45" width="45" />
                <?php endif; ?>
            </div>
        </div>

        <div class="row">
            <label class="col-sm-3 control-label"></label>
            <div class="col-sm-6">
                <?php echo Form::file('name'); ?>

            </div>
        </div>


        <div class="bg-default content-box text-center pad20A mrg25T">
            <input class="btn btn-lg btn-primary" type="submit" id="submitButton" value="save" onclick="submitted()">
        </div>

    <?php echo e(Form::close()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>