<?php $__env->startSection('contentheader'); ?>
	Users List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
	Users List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>

	<div class="panel-heading">
		
			<a href="<?php echo e(route('user.new')); ?>" class="btn btn-success btn-alt btn-xs" style="border-radius: 0px !important;">
				<i class='fa fa-plus'></i> 
				Create New User
			</a>
		

		<?php if(count(Request::input())): ?>
			<span class="pull-right">	
	            <a class="btn btn-default btn-alt btn-xs" href="<?php echo e(action('UserController@getIndex')); ?>">
	            	<i class="fa fa-eraser"></i> 
	            	<?php echo e(trans('core.clear')); ?>

	            </a>

	            <a class="btn btn-primary btn-alt btn-xs" id="searchButton">
	            	<i class="fa fa-search"></i> 
	            	<?php echo e(trans('core.modify_search')); ?>

	            </a>
	        </span>
        <?php else: ?>
            <a class="btn btn-primary btn-alt btn-xs pull-right" id="searchButton">
				<i class="fa fa-search"></i>
				Search
			</a>
        <?php endif; ?>
	</div>

	<div class="panel-body">

		<table class="table table-bordered">
			<thead class="bg-gradient-1">
				<td class="text-center font-white">#</td>
				<td class="text-center font-white">Name</td>
				<td class="text-center font-white">Email</td>
				<td class="text-center font-white">Role</td>
				<td class="text-center font-white">Actions</td>
			</thead>

			<tbody>
				<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td class="text-center"><?php echo e($loop->iteration); ?></td>
						<td class="text-center"><?php echo e($user->name); ?></td>
						<td class="text-center"><?php echo e($user->email); ?></td>
						<td class="text-center">
							<?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php echo e($role->name); ?>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</td>
						<td class="text-center">
							<?php if(auth()->user()->can('user.manage')): ?>
								<a href="<?php echo e(route('user.edit', $user)); ?>" class="btn btn-info btn-alt btn-xs">
									<i class="fa fa-edit"></i>
									Edit
								</a>

								<a type="button" data-toggle="modal" data-target="#userAction<?php echo e($user->id); ?>">
									<?php if($user->inactive == 1): ?>
										<span class="btn btn-success btn-alt btn-xs">
											Activate
										</span>
									<?php else: ?>
										<span class="btn btn-danger btn-alt btn-xs">
											Deactivate
										</span>
									<?php endif; ?>
								</a>
							<?php else: ?>
								<a href="#" class="btn btn-border btn-alt border-blue btn-link font-blue btn-xs" disabled>
									<i class="fa fa-edit"></i>
									Edit
								</a>
							<?php endif; ?>							
						</td>
					</tr>

					<!-- Activate / Deactivate User -->
					<div class="modal fade" id="userAction<?php echo e($user->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
					  <form method="post" action="<?php echo e(route('user.status')); ?>">
					  	<?php echo e(csrf_field()); ?>

					  <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
					  <div class="modal-dialog" role="document">
					    <div class="modal-content">
					      <div class="modal-header">
					        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					        <h4 class="modal-title" id="myModalLabel">
					        	<?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?> is currently <?php if($user->inactive == 1): ?> Inactive <?php else: ?> Active <?php endif; ?>
					        </h4>
					      </div>
					      <div class="modal-body">
					        Do you want to <?php if($user->inactive == 1): ?> Activate  <?php else: ?> Deactivate <?php endif; ?> this user
					      </div>

					      <div class="modal-footer">
					        <button type="button" class="btn btn-success" data-dismiss="modal">No</button>
					        <button type="submit" class="btn btn-danger">Yes</button>
					      </div>
					      </form>
					    </div>
					  </div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>

		<!--Pagination-->
		<div class="pull-right">
			<?php echo e($users->links()); ?>

		</div>
		<!--Ends-->
	</div>

	<!-- User search modal -->
    <div class="modal fade" id="searchModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST" action="http://inventory.intelle-hub.com/admin/user" accept-charset="UTF-8" class="form-horizontal"><input name="_token" type="hidden" value="Mw4ica7M5FhbUlKEpyqPYZ88YAJPVAoYw7EbPnVL">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"> Search Customer</h4>
                </div>

                <div class="modal-body">                  
                    <div class="form-group">
                        <label for="Name" class="col-sm-3">Name</label>
                        <div class="col-sm-9">
                            <input class="form-control" name="name" type="text">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="Email" class="col-sm-3">Email</label>
                        <div class="col-sm-9">
                            <input class="form-control" name="email" type="text">
                        </div>
                    </div>                                             
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <input class="btn btn-primary" data-disable-with="core.searching" type="submit" value="Search">
                </div>
                </form>
            </div>
        </div>
    </div>
	<!-- search modal ends -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
	<script>
		$(function() {
            $('#searchButton').click(function(event) {
                event.preventDefault();
                $('#searchModal').modal('show')
            });
        })
	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>