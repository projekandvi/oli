<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Database Config
    |--------------------------------------------------------------------------
    |
    | Here you can specify Addchat database settings
    |
    */
    'database' => [
        'autoload_migrations' => true,
    ],

];


